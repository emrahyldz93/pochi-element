<?php
namespace PochiElement\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use \Elementor\Repeater;

// Security Note: Blocks direct access to the plugin PHP files.
defined('ABSPATH') || die();

class Pochi_Contact extends Widget_Base
{

    public function get_name()
    {
        return 'pochi-contact';
    }

    public function get_title()
    {
        return esc_html__('Pochi Contact', 'pochi');
    }

    public function get_icon()
    {
        return 'eicon-mail';
    }

    public function get_categories()
    {
        return array('general');
    }

    public function _register_controls()
    {

        // Header Settings
        $this->start_controls_section(
            'header_section',
            [
                'label' => __('Contact', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

     
      
        $this->add_control(
            'contact_title',
            [
                'label' => __('Contact Title', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Got a Project? Les’t Talk', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your title here', 'pochi-element'),

            ]
        );

        $this->add_control(
            'contact_address',
            [
                'label' => __('Contact Address', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('004 Riley Street, Surry Hills 2050 Sydney, Australia', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your address here', 'pochi-element'),

            ]
        );
        $this->add_control(
            'contact_phone',
            [
                'label' => __('Contact Phone', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('+0234 233 423 444', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your phone here', 'pochi-element'),

            ]
        );

        $this->add_control(
            'contact_mail',
            [
                'label' => __('Contact Mail', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('info@jhondoe.com', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your mail here', 'pochi-element'),

            ]
        );
     


        $this->end_controls_section();
        // Header Settings
        $this->start_controls_section(
            'form_section',
            [
                'label' => __('Form', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'contact_form_title',
            [
                'label' => __('Contact Form Title ', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Estimate your project? <br> Lest me know here', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your title here', 'pochi-element'),

            ]
        );
        $this->add_control(
            'contact_form',
            [
                'label' => __('Contact Form 7 Shortcode ', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('[contact-form-7 id="208" title="İletişim formu 1"]', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your shortcode here', 'pochi-element'),

            ]
        );

      

        $this->end_controls_section();

        // Style Tab
        $this->style_tab();
    }

    private function style_tab()
    {}

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
        <section id="contact">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-12 p-20">
                        <div class="contact-title">
                            <h3><?php echo $settings['contact_title']; ?></h3>
                        </div>
                        <div class="contact-desc">
                            <address><?php echo $settings['contact_address']; ?></address>
                            <span><a href="tel:<?php echo $settings['contact_phone']; ?>"> <?php echo $settings['contact_phone']; ?></a></span>
                            <p><a href="mail-to:<?php echo $settings['contact_mail']; ?>"><?php echo $settings['contact_mail']; ?> <i class="fas fa-arrow-right "></i></a> </p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-12 p-20">
                        <div class="contact-form-title">
                            <h3><?php echo $settings['contact_form_title']; ?></h3>
                        </div>
                        <?php echo do_shortcode($settings['contact_form']) ; ?>
                       
                    </div>
                </div>
            </div>
        </section>
     
    
     

        <?php
}

}