<?php

namespace PochiElement\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use \Elementor\Repeater;

// Security Note: Blocks direct access to the plugin PHP files.
defined('ABSPATH') || die();

class Pochi_About extends Widget_Base
{

    public function get_name()
    {
        return 'pochi-about';
    }

    public function get_title()
    {
        return esc_html__('Pochi About', 'pochi');
    }

    public function get_icon()
    {
        return ' eicon-text';
    }

    public function get_categories()
    {
        return array('general');
    }

    public function _register_controls()
    {

        // Header Settings
        $this->start_controls_section(
            'header_section',
            [
                'label' => __('Skills', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // List Repeater
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'skill_icon',
            [
                'label' => __('Skill Icon', 'text-domain'),
                'type' => \Elementor\Controls_Manager::ICONS,

            ]
        );
        $repeater->add_control(
            'skill_ratio',
            [
                'label' => __('Ratio', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 5,
                'max' => 100,
                'step' => 5,
                'default' => 85,
            ]
        );


        $this->add_control(
            'list',
            [
                'label' => __('Skills List', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'skill_icon' => [
                            'value' => 'fab fa-wordpress',
                            'library' => 'fa-brands',
                        ],

                    ],

                    [
                        'skill_icon' => [
                            'value' => 'fab fa-node-js',
                            'library' => 'fa-brands',
                        ],
                    ],
                    [
                        'skill_icon' => [
                            'value' => 'fab fa-angular',
                            'library' => 'fa-brands',
                        ],
                    ],
                    [
                        'skill_icon' => [
                            'value' => 'fab fa-html5',
                            'library' => 'fa-brands',
                        ],
                    ],
                    [
                        'skill_icon' => [
                            'value' => 'fab fa-python',
                            'library' => 'fa-brands',
                        ],
                    ],


                ],
                'title_field' => '<# var migrated = "undefined" !== typeof __fa4_migrated, social = ( "undefined" === typeof social ) ? false : social; #>{{{ elementor.helpers.getSocialNetworkNameFromIcon( skill_icon, social, true, migrated, true ) }}}',
            ]
        );

        $this->end_controls_section();
        // Header Settings
        $this->start_controls_section(
            'skills_section',
            [
                'label' => __('Experiences', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // List Repeater
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'experiences_year',
            [
                'label' => __('Experiences Year', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('2021', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your year here', 'pochi-element'),

            ]
        );


        $repeater->add_control(
            'experiences_desc',
            [
                'label' => __('Experiences Desc', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => __('<h3>IOS Developer</h3>
                <p>FREELANCE</p>
                <h3>Senior Product Manager</h3>
                <p>FREELANCE</p>
                <h3>Senior Wp Front end Developer</h3>
                <p>XXX STUDIO</p>', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your desc here', 'pochi-element'),

            ]
        );

        $this->add_control(
            'list1',
            [
                'label' => __('Experiences List', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    
                    [
                        'experiences_year' => __( '2021', 'pochi-element' ),
                    ],
                    [
                        'experiences_year' => __( '2020', 'pochi-element' ),
                    ],

                    

                  


                ],
                'title_field' => '{{{ experiences_year }}}',
            ]
        );

        $this->end_controls_section();

        // Style Tab
        $this->style_tab();
    }

    private function style_tab()
    {
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
		
?>
        <section id="skill">
            <div class="container">
                <div class="row">
                    <div class="col-xl-7 col-lg-12">
                        <?php foreach ($settings['list'] as $item) : ?>
                            <div class="skill-box">
                                <div class="content">
                                    <?php \Elementor\Icons_Manager::render_icon($item['skill_icon'], ['aria-hidden' => 'true']); ?>
                                    <b><?php echo $item['skill_ratio']; ?>%</b>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="col-xl-5 col-lg-12">
                        <div class="swiper ex-swiper">
                            <div class="swiper-wrapper">
                                <?php foreach ($settings['list1'] as $item) : ?>
                                    <div class="swiper-slide">
                                        <div class="experiences">
                                            <div class="year"><span><?php echo $item['experiences_year']; ?></span></div>
                                            <div class="ex-content">
                                            <?php   echo $item['experiences_desc'] ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="ex-pagination"></div>
                    </div>
                </div>
            </div>
        </section>




<?php
    }
}
