<?php

namespace PochiElement\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use \Elementor\Repeater;

// Security Note: Blocks direct access to the plugin PHP files.
defined('ABSPATH') || die();

class Pochi_Portfolio extends Widget_Base
{

    public function get_name()
    {
        return 'pochi-portfolio';
    }

    public function get_title()
    {
        return esc_html__('Pochi Portfolio', 'pochi');
    }

    public function get_icon()
    {
        return 'eicon-archive-posts';
    }

    public function get_categories()
    {
        return array('general');
    }

    public function _register_controls()
    {

        // Header Settings
        $this->start_controls_section(
            'header_section',
            [
                'label' => __('Portfolio', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

       
        $this->add_control(
            'portfolio_count',
            [
                'label' => __('Portfolio Count', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,




            ]
        );

     

        $this->end_controls_section();

        // Style Tab
        $this->style_tab();
    }

    private function style_tab()
    {
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
?>
        <section id="portfolio">
            <div class="container-fluid">
                <div class="row">
                    <div class="swiper portfolio-swiper">
                        <div class="swiper-wrapper">                     
                                    <?php
                                    $args = array('post_type' => 'portfolio', 'posts_per_page' => $settings['portfolio_count']);
                                    $recent_posts = wp_get_recent_posts($args);
                                    foreach ($recent_posts as $recent) {
                                    ?>
                                        <div class="swiper-slide">
                                            <img class="img-fluid d-none" src="<?php echo  get_the_post_thumbnail_url($recent["ID"], 'medium-large'); ?>" alt="" />
                                            <h3><a href=" <?php echo esc_url(get_the_permalink($recent["ID"])); ?>"> <?php echo esc_html($recent["post_title"]) ?></a></h3>
                                        </div>
                                        <?php }wp_reset_query(); ?> 
   
                        </div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
        </section>


<?php
    }
}
