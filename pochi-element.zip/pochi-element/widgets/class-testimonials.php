<?php
namespace PochiElement\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use \Elementor\Repeater;

// Security Note: Blocks direct access to the plugin PHP files.
defined('ABSPATH') || die();

class Pochi_Testimonials extends Widget_Base
{

    public function get_name()
    {
        return 'pochi-testimonials';
    }

    public function get_title()
    {
        return esc_html__('Pochi Testimonials', 'pochi');
    }

    public function get_icon()
    {
        return 'eicon-testimonial';
    }

    public function get_categories()
    {
        return array('general');
    }

    public function _register_controls()
    {

        // Header Settings
        $this->start_controls_section(
            'header_section',
            [
                'label' => __('Testimonials', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // List Repeater
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'testimonials_image',
            [
                'label' => __('Testimonials Image', 'text-domain'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],

            ]
        );
 
        $repeater->add_control(
            'testimonials_desc',
            [
                'label' => __('Testimonials Description', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('“ Hendrerit ac nisi Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tate, tortor nec commodo ultricies vitae viverra urna. ”', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your Description here', 'pochi-element'),

            ]
        );

        $repeater->add_control(
            'testimonials_author',
            [
                'label' => __('Testimonials Author', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('<p>Tony Nguyen</p> <span> - Ceo Moontheme</span>', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your author here', 'pochi-element'),

            ]
        );
     
        $this->add_control(
            'list',
            [
                'label' => __('Testimonials List', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'testimonials_desc' => __( '“ Hendrerit ac nisi Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tate, tortor nec commodo ultricies vitae viverra urna. ”', 'pochi-element' ),
                    ],
                    [
                        'testimonials_desc' => __( '“ Hendrerit ac nisi Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tate, tortor nec commodo ultricies vitae viverra urna. ”', 'pochi-element' ),
                    ],

               

                ],
                'title_field' => '{{{  testimonials_desc }}}',
            ]
        );

        $this->end_controls_section();
        // Header Settings
        $this->start_controls_section(
            'thumb_section',
            [
                'label' => __('Thumbs', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

          // List Repeater
          $repeater = new \Elementor\Repeater();
          $repeater->add_control(
              'testimonials_icon',
              [
                  'label' => __('Testimonials Icon', 'text-domain'),
                  'type' => \Elementor\Controls_Manager::ICONS,
  
              ]
          );

        $this->add_control(
            'list1',
            [
                'label' => __('Thumbs List', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'testimonials_icon' => [
                            'value' => 'fab fa-angrycreative',
                            'library' => 'fa-brands',
                        ],

                    ],

                    [
                        'testimonials_icon' => [
                            'value' => 'fab fa-staylinked',
                            'library' => 'fa-brands',
                        ],
                    ],
                

                ],
                'title_field' => '<# var migrated = "undefined" !== typeof __fa4_migrated, social = ( "undefined" === typeof social ) ? false : social; #>{{{ elementor.helpers.getSocialNetworkNameFromIcon( testimonials_icon, social, true, migrated, true ) }}}',
            ]
        );

        $this->end_controls_section();

        // Style Tab
        $this->style_tab();
    }

    private function style_tab()
    {}

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
         <section id="testimonials">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="swiper testimonials-swiper">
                            <div class="swiper-wrapper">

                            <?php foreach ($settings['list'] as $item): ?>
                                <div class="swiper-slide">
                                    <div class="author">
                                        <img src="<?php echo $item['testimonials_image']['url']; ?>" alt="">
                                    </div>
                                    <div class="testimonials-content ">
                                        <p><?php echo $item['testimonials_desc']; ?></p>
                                    </div>
                                    <div class="testimonials-meta">
                                    <?php echo $item['testimonials_author']; ?>
                                    </div>
                                </div>
                             
                                <?php endforeach;?> 
                            
                            </div>

                        </div>
                        <div thumbsSlider="" class=" testimonials-thumbs">
                            <div class="swiper-wrapper">

                            <?php foreach ($settings['list1'] as $item): ?>
                                <div class="swiper-slide">
                                <?php \Elementor\Icons_Manager::render_icon($item['testimonials_icon'], ['aria-hidden' => 'true']);?>
                                </div>
                            <?php endforeach;?> 

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    
     

        <?php
}

}