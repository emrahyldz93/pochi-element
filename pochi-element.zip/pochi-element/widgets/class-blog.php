<?php

namespace PochiElement\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use \Elementor\Repeater;

// Security Note: Blocks direct access to the plugin PHP files.
defined('ABSPATH') || die();

class Pochi_Blog extends Widget_Base
{

    public function get_name()
    {
        return 'pochi-blog';
    }

    public function get_title()
    {
        return esc_html__('Pochi Blog Post', 'pochi');
    }

    public function get_icon()
    {
        return 'eicon-post';
    }

    public function get_categories()
    {
        return array('general');
    }

    public function _register_controls()
    {

        // Header Settings
        $this->start_controls_section(
            'header_section',
            [
                'label' => __('Blog Post', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );


        $this->add_control(
            'blog_count',
            [
                'label' => __('Blog Count', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,




            ]
        );



        $this->end_controls_section();

        // Style Tab
        $this->style_tab();
    }

    private function style_tab()
    {
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
?>
        <section id="blog">
            <div class="container-fluid">
                <div class="row">
                    <?php
                    $args = array( 'posts_per_page' => $settings['blog_count']);
                    $recent_posts = wp_get_recent_posts($args);
                    foreach ($recent_posts as $recent) {
                    ?>
                        <div class="col-xl-4 col-lg-12 p-20 general-blog">
                            <a href="<?php echo esc_url(get_the_permalink($recent["ID"])); ?>">
                            <div class="blog-image">
                                <img class="img-fluid " src="<?php echo  get_the_post_thumbnail_url($recent["ID"], 'medium'); ?>" alt="" />
                            </div>
                            <div class="blog-info">
                                <h1><?php echo esc_html($recent["post_title"]) ?></h1>
                                <p><?php echo substr(esc_html($recent["post_excerpt"]), 0, 80); ?></p>
                                <i><?php echo __('Read More','pochi-element' )?></i>
                            </div>
                            </a>
                        </div>
                    <?php }
                    wp_reset_query(); ?>

                </div>
        </section>


<?php
    }
}
