<?php

namespace PochiElement\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;

// Security Note: Blocks direct access to the plugin PHP files.
defined('ABSPATH') || die();

class General_Title1 extends Widget_Base
{

    public function get_name()
    {
        return 'pochi-general-title';
    }

    public function get_title()
    {
        return esc_html__('Pochi General title', 'pochi');
    }

    public function get_icon()
    {
        return 'eicon-product-title';
    }

    public function get_categories()
    {
        return array('general');
    }

    public function _register_controls()
    {

        // Header Settings
        $this->start_controls_section(
            'header_section',
            [
                'label' => __('general Title', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        // Title
        $this->add_control(
            'general_title',
            [
                'label' => __('Title', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('title', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your sub title here', 'pochi-element'),
            ]
        );
        // Title
        $this->add_control(
            'general_sub_title',
            [
                'label' => __('Title', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Sub Title', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your  title here', 'pochi-element'),
            ]
        );

        $this->end_controls_section();

        // Style Tab
        $this->style_tab();
    }

    private function style_tab()
    {
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
?>
        <div class="container mt-90">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <span class="section-subtitle"><?php echo $settings['general_sub_title']; ?></span>
                    <h2 class="section-title"><?php echo $settings['general_title']; ?></h2>
                </div>
            </div>
        </div>
<?php
    }
}
