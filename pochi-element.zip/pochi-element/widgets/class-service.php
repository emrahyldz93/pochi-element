<?php
namespace PochiElement\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use \Elementor\Repeater;

// Security Note: Blocks direct access to the plugin PHP files.
defined('ABSPATH') || die();

class Pochi_Service extends Widget_Base
{

    public function get_name()
    {
        return 'pochi-service';
    }

    public function get_title()
    {
        return esc_html__('Pochi Service', 'pochi');
    }

    public function get_icon()
    {
        return 'eicon-post-list';
    }

    public function get_categories()
    {
        return array('general');
    }

    public function _register_controls()
    {

        // Header Settings
        $this->start_controls_section(
            'header_section',
            [
                'label' => __('Service', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // List Repeater
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'service_icon',
            [
                'label' => __('Service Icon', 'text-domain'),
                'type' => \Elementor\Controls_Manager::ICONS,

            ]
        );
        $repeater->add_control(
            'service_title',
            [
                'label' => __('Service Title', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Title Here', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your title here', 'pochi-element'),

            ]
        );
        $repeater->add_control(
            'service_desc',
            [
                'label' => __('Service Description', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __(' Vel magna lacinia ultrices Sed id interdum urna', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your description here', 'pochi-element'),
               

            ]
        );

        $this->add_control(
            'list',
            [
                'label' => __('Social Icon List', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'service_icon' => [
                            'value' => 'fas fa-mobile',
                            'library' => 'fa-brands',
                        ],

                    ],

                    [
                        'service_icon' => [
                            'value' => 'fas fa-code',
                            'library' => 'fa-brands',
                        ],
                    ],
                    [
                        'service_icon' => [
                            'value' => 'fas fa-sign-language',
                            'library' => 'fa-brands',
                        ],
                    ],

                ],
                'title_field' => '<# var migrated = "undefined" !== typeof __fa4_migrated, social = ( "undefined" === typeof social ) ? false : social; #>{{{ elementor.helpers.getSocialNetworkNameFromIcon( service_icon, social, true, migrated, true ) }}}',
            ]
        );

        $this->end_controls_section();

        // Style Tab
        $this->style_tab();
    }

    private function style_tab()
    {}

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
        <section id="what-i-do">
            <div class="container">
                <div class="row">
                <?php foreach ($settings['list'] as $item): ?>
                    <div class="col-xl-4 col-lg-12 nht-box">
                        <div class="icon-box">
                       
                            <div class="icon">
                            <?php \Elementor\Icons_Manager::render_icon($item['service_icon'], ['aria-hidden' => 'true']);?>
                            </div>
                            
                            <div class="content">
                                <h3><?php echo $item['service_title']; ?></h3>
                                <p><?php echo $item['service_desc']; ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach;?>

                </div>
            </div>
        </section>

        <?php
}

}