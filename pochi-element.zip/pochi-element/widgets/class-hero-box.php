<?php

namespace PochiElement\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use \Elementor\Repeater;

// Security Note: Blocks direct access to the plugin PHP files.
defined('ABSPATH') || die();

class Hero_Box extends Widget_Base
{

    public function get_name()
    {
        return 'pochi-hero-box';
    }

    public function get_title()
    {
        return esc_html__('Pochi Hero Box', 'pochi');
    }

    public function get_icon()
    {
        return 'eicon-info-box';
    }

    public function get_categories()
    {
        return array('general');
    }

    public function _register_controls()
    {

        // Header Settings
        $this->start_controls_section(
            'header_section',
            [
                'label' => __('Left', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // Title
        $this->add_control(
            'header_title',
            [
                'label' => __('Title', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Hello! i’m Pochi Cox.', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your title here', 'pochi-element'),
            ]
        );
        // Title
        $this->add_control(
            'header_sub_title',
            [
                'label' => __('Sub Title', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Freelance Web & Mobile Development', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your sub title here', 'pochi-element'),
            ]
        );

        // Description
        $this->add_control(
            'header_description',
            [
                'label' => __('Description', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'rows' => 5,
                'default' => __(' Vestibulum imperdiet nibh vel magna lacinia ultrices. Sed id interdum urna', 'pochi-element'),
                'placeholder' => __('Type your description here', 'pochi-element'),
            ]
        );

        // button
        $this->add_control(
            'header_button_text',
            [
                'label' => __('Button One', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Hire Me', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your text here', 'pochi-element'),
            ]
        );
        // button
        $this->add_control(
            'header_button_url',
            [
                'label' => __('Button One Url', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::URL,
                'label_block' => true,
                'placeholder' => __('Type your URL here', 'pochi-element'),
            ]
        );

        // button2
        $this->add_control(
            'header_button_text2',
            [
                'label' => __('Button Two', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Let’s Chat', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your text here', 'pochi-element'),
            ]
        );
        // button 2
        $this->add_control(
            'header_button_url2',
            [
                'label' => __('Button two URL', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::URL,
                'label_block' => true,
                'placeholder' => __('Type your URL here', 'pochi-element'),
            ]
        );

        // List Repeater
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'feature_icon',
            [
                'label' => __('Social Icon', 'text-domain'),
                'type' => \Elementor\Controls_Manager::ICONS,

            ]
        );
        $repeater->add_control(
            'feature_text',
            [
                'label' => __('Icon URL', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::URL,

            ]
        );

        $this->add_control(
            'list',
            [
                'label' => __('Social Icon List', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'feature_icon' => [
                            'value' => 'fab fa-dribbble',
                            'library' => 'fa-brands',
                        ],
                    ],
                    [
                        'feature_icon' => [
                            'value' => 'fab fa-behance',
                            'library' => 'fa-brands',
                        ],
                    ],
                    [
                        'feature_icon' => [
                            'value' => 'fab fa-twitter',
                            'library' => 'fa-brands',
                        ],
                    ],
                    [
                        'feature_icon' => [
                            'value' => 'fab fa-instagram',
                            'library' => 'fa-brands',
                        ],
                    ],
                ],
                'title_field' => '<# var migrated = "undefined" !== typeof __fa4_migrated, social = ( "undefined" === typeof social ) ? false : social; #>{{{ elementor.helpers.getSocialNetworkNameFromIcon( feature_icon, social, true, migrated, true ) }}}',
            ]
        );

        $this->end_controls_section();

        // Price Settings
        $this->start_controls_section(
            'price_section',
            [
                'label' => __('Center', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // hero img
        $this->add_control(
            'hero_image',
            [
                'label' => __('Image', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();

        // Listing Settings
        $this->start_controls_section(
            'listing_section',
            [
                'label' => __('Right', 'pochi'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'right_title',
            [
                'label' => __('Box One Title', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Web & mobile Developent.', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your title here', 'pochi-element'),
            ]
        );

        $this->add_control(
            'right_number',
            [
                'label' => __('Box One Number', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => __('160', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your number here', 'pochi-element'),
            ]
        );
        $this->add_control(
            'right_sub_title',
            [
                'label' => __('Box One Sub Title', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Best Project.', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your title here', 'pochi-element'),
            ]
        );

        $this->add_control(
            'hero_right_img',
            [
                'label' => __('Image', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'hr2',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );
        $this->add_control(
            'right_title1',
            [
                'label' => __('Box Two Title', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('System connection solution.', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your title here', 'pochi-element'),
            ]
        );
        $this->add_control(
            'right_big_title',
            [
                'label' => __('Box Two Big Title', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Quality solution', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your title here', 'pochi-element'),
            ]
        );

        $this->add_control(
            'right_sub_title2',
            [
                'label' => __('Box Two Sub Title', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Happy Customers', 'pochi-element'),
                'label_block' => true,
                'placeholder' => __('Type your title here', 'pochi-element'),
            ]
        );

        $this->add_control(
            'hero_right_img1',
            [
                'label' => __('Image', 'pochi-element'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab
        $this->style_tab();
    }

    private function style_tab()
    {
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
?>
        <section id="hero-box">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-2 col-lg-12 scroll-end d-none d-sm-block">
                        <div class="scroll-down">
                            <p>Scroll down</p>
                            <i class="fas fa-chevron-down"></i>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-12">
                        <div class="hero-content">
                            <h1 class="hero-text"><?php echo $settings['header_title']; ?></span>
                            </h1>
                            <h3><?php echo $settings['header_sub_title']; ?></h3>
                            <p>
                                <?php echo $settings['header_description']; ?>
                            </p>
                            <div class="button-set">
                                <button class="btn"><a href="<?php echo $settings['header_button_url']; ?>"> <?php echo $settings['header_button_text']; ?></a></button>
                                <button class="btn let-chat"><a href="<?php echo $settings['header_button_url2']; ?>"> <?php echo $settings['header_button_text2']; ?></a></button>
                            </div>
                            <div class="icon-set">
                                <ul>
                                    <?php foreach ($settings['list'] as $item) : ?>
                                        <li>
                                            <a href="<?php echo $item['feature_text']; ?>"><?php \Elementor\Icons_Manager::render_icon($item['feature_icon'], ['aria-hidden' => 'true']); ?></a>
                                        </li>
                                    <?php endforeach; ?>

                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-12 ">
                        <div class="hero-image">
                            <img class="img-fluid" src="<?php echo $settings['hero_image']['url']; ?>" />
                            <span class="shape1"></span>
                            <span class="shape2"></span>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-12">
                        <div class="quik-info">
                            <div class="web-box">
                                <div class="title">
                                    <h5>
                                        <?php echo $settings['right_title']; ?>
                                    </h5>
                                </div>
                                <div class="project">
                                    <span> <?php echo $settings['right_number']; ?></span>
                                    <p><?php echo $settings['right_sub_title']; ?></p>
                                </div>
                                <div class="web-image">
                                    <img src="<?php echo $settings['hero_right_img']['url']; ?>" alt="" />
                                </div>
                            </div>

                            <div class="system-box">
                                <div class="title">
                                    <h5>
                                        <?php echo $settings['right_title1']; ?>
                                    </h5>
                                </div>
                                <div class="project">
                                    <span><?php echo $settings['right_big_title']; ?></span>
                                    <p><?php echo $settings['right_sub_title2']; ?></p>
                                </div>
                                <div class="web-image">
                                    <img src="<?php echo $settings['hero_right_img1']['url']; ?>" alt="" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

<?php
    }
}
