<?php
/**
 * Pochi Element WordPress Plugin
 *
 * @package PochiElement
 *
 * Plugin Name: Pochi Element
 * Description: Pochi Element
 * Plugin URI:  https://emrahyldz.com
 * Version:     1.0.0
 * Author:      Emrah Yıldız
 * Author URI:  https://www.emrahyldz.com
 * Text Domain: pochi-element
 */

define( 'ELEMENTOR_AWESOMESAUCE', __FILE__ );

/**
 * Include the Elementor_Awesomesauce class.
 */
require plugin_dir_path( ELEMENTOR_AWESOMESAUCE ) . 'class-elementor-pochielement.php';
